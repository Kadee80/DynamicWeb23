export default function ArtSearch() {
  return <div>Art Search</div>
}
