export default function ArtForm() {
  return <div>Art Form</div>
}
