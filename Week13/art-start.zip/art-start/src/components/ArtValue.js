export default function ArtValue() {
  return <div>Art Value</div>
}
