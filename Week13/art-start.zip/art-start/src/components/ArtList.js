export default function ArtList() {
  return <div>Art List</div>
}
