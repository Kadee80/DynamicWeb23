import {useSelector, useDispatch} from 'react-redux'
import {removeArt} from '../store'

export default function ArtList() {
  const dispatch = useDispatch()
  // pass 1 - get entire list of art items from store
  // const artList = useSelector((state) => {
  //   return state.art.data
  // })

  const {artList, name} = useSelector(({form, art: {data, searchTerm}}) => {
    // const {art} = state
    // const {data, searchTerm} = art
    // does the name of a art item contain our search term
    const filteredArt = data.filter((art) =>
      art.name.toLowerCase().includes(searchTerm.toLowerCase())
    )

    return {
      artList: filteredArt,
      name: form.name,
    }
  })

  const handleArtDelete = (art) => {
    // pass in the ID of the art item we want to delete as payload
    dispatch(removeArt(art.id))
  }

  const renderedArt = artList.map((art) => {
    // DECIDE HERE if this art should be bold
    const bold = name && art.name.toLowerCase().includes(name.toLowerCase())
    return (
      <div
        key={art.id}
        className="border rounded flex flex-row justify-between items-center"
      >
        <p className={`${bold && 'font-bold'}`}>
          {art.name} - ${art.price}
        </p>
        <button
          className="rounded bg-red-500 p-2 text-white"
          onClick={() => handleArtDelete(art)}
        >
          Delete
        </button>
      </div>
    )
  })

  return <div className="p-5">{renderedArt}</div>
}
