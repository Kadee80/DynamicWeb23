export default function Table({data, config, keyFn}) {
  const renderedHeaders = config.map((col) => {
    return <th key={col.label}>{col.label}</th>
  })

  const renderedRows = data.map((rowData) => {
    const renderedCells = config.map((col) => {
      return (
        <td key="col.label" className="p-2">
          {col.render(rowData)}
        </td>
      )
    })
    return (
      <tr key={keyFn(rowData)} className="border-b border-slate-200">
        {renderedCells}
      </tr>
    )
  })
  return (
    <table className="table-auto border-spacing-2">
      <thead>
        <tr className="border-b-2 border-slate-500">{renderedHeaders}</tr>
      </thead>
      <tbody>{renderedRows}</tbody>
    </table>
  )
}
