export default function Table({data}) {
  const renderedRows = data.map((veg) => {
    return (
      <tr key={veg.name} className="border-b border-slate-200">
        <td className="p-3">{veg.name}</td>
        <td className="p-3">{veg.color}</td>
        <td className="p-3">{veg.count}</td>
      </tr>
    )
  })
  return (
    <table className="table-auto border-spacing-2">
      <thead>
        <tr className="border-b-2 border-slate-500">
          <th>Produce</th>
          <th>Color</th>
          <th>Count</th>
        </tr>
      </thead>
      <tbody>{renderedRows}</tbody>
    </table>
  )
}
