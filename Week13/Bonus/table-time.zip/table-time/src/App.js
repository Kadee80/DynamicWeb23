import Table from './components/Table'

// Just some starter data to populate our table
const data = [
  {name: 'Pumpkin', color: 'bg-orange-500', count: 5},
  {name: 'Cucumber', color: 'bg-green-500', count: 12},
  {name: 'Tomato', color: 'bg-red-500', count: 23},
  {name: 'Eggplant', color: 'bg-purple-500', count: 7},
  {name: 'Pepper', color: 'bg-yellow-500', count: 8},
  {name: 'Blueberry', color: 'bg-blue-500', count: 50},
]
export default function App() {
  return (
    <div className="container p-5">
      <Table data={data} />
    </div>
  )
}
