import Table from './components/Table'

// Just some starter data to populate our table
const data = [
  {name: 'Pumpkin', color: 'bg-orange-500', count: 5, price: 12.0},
  {name: 'Cucumber', color: 'bg-green-500', count: 12, price: 1.0},
  {name: 'Tomato', color: 'bg-red-500', count: 23, price: 0.5},
  {name: 'Eggplant', color: 'bg-purple-500', count: 7, price: 3.0},
  {name: 'Pepper', color: 'bg-yellow-500', count: 8, price: 1.25},
  {name: 'Blueberries', color: 'bg-blue-500', count: 50, price: 0.1},
]

const config = [
  {label: 'Name', render: (veg) => veg.name},
  {
    label: 'Color',
    render: (veg) => <div className={`p-3 m-2 ${veg.color}`}></div>,
  },
  // this header has a header render function, just like we have for our table cells!
  // this one is a silly red bg, but it shows we can add something like onClick,
  // or maybe render an icon to show this column is sortable,
  // see the table component for how it is conditionally rendered
  {
    label: 'Count',
    render: (veg) => veg.count,
    header: () => (
      <th className="bg-red-500" key={Math.random()}>
        Count
      </th>
    ),
  },
  {label: 'Price Per', render: (veg) => veg.price},
  // computed columns
  {label: 'Total Price', render: (veg) => veg.count * veg.price},
]

// we need a dynamic key fn so we dont hardcode it into our reusable table
const keyFn = (item) => {
  return item.name
}

// alternative data just to prove we can reuse our table component!
/*
const data2 = [
  {name: 'hello', count: 10},
  {name: 'bye', count: 100},
]

const config2 = [
  {label: 'Greeting', render: (item) => item.name},
  {label: 'Waves', render: (item) => item.count * 5},
]
*/

export default function App() {
  return (
    <div className="container p-5">
      <Table data={data} config={config} keyFn={keyFn} />
    </div>
  )
}
