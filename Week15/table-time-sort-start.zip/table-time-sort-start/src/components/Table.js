export default function Table({data, config, keyFn}) {
  const renderedHeaders = config.map((col) => {
    // this is new! if we have a header "render" function, call it
    // otherwise, just print the label
    if (col.header) {
      return col.header()
    }
    return (
      <th key={col.label} className="p-2">
        {col.label}
      </th>
    )
  })

  const renderedRows = data.map((rowData) => {
    const renderedCells = config.map((col) => {
      return (
        <td key={col.label} className="p-2">
          {col.render(rowData)}
        </td>
      )
    })
    return (
      <tr key={keyFn(rowData)} className="border-b border-slate-200">
        {renderedCells}
      </tr>
    )
  })
  return (
    <table className="table-auto border-spacing-2">
      <thead>
        <tr className="border-b-2 border-slate-500 text-left">
          {renderedHeaders}
        </tr>
      </thead>
      <tbody>{renderedRows}</tbody>
    </table>
  )
}
