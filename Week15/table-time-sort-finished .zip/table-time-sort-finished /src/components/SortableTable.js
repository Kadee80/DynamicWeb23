import {useState} from 'react'
import {GoChevronUp, GoChevronDown} from 'react-icons/go'

import Table from './Table'

export default function SortableTable(props) {
  const [sortOrder, setSortOrder] = useState(null)
  const [sortBy, setSortBy] = useState(null)
  const {config, data} = props

  const handleClick = (label) => {
    // LAST! when we have a new sortBy column
    // switch to new sortBy and assume asc order
    if (sortBy && label !== sortBy) {
      setSortOrder('asc')
      setSortBy(label)
      // skipp all other checks and return early
      return
    }

    if (sortOrder === null) {
      setSortOrder('asc')
      setSortBy(label)
    } else if (sortOrder === 'asc') {
      setSortOrder('desc')
      setSortBy(label)
    } else if (sortOrder === 'desc') {
      setSortOrder(null)
      setSortBy(null)
    }
  }

  const updatedConfig = config.map((col) => {
    if (!col.sortValue) {
      return col
    }

    return {
      ...col,
      header: () => (
        <th
          className="cursor-pointer hover:bg-gray-100"
          onClick={() => handleClick(col.label)}
        >
          <div className="flex items-center">
            {getIcons(col.label, sortBy, sortOrder)}
            {col.label}
          </div>
        </th>
      ),
    }
  })

  // Only sort data if sortOrder && sortBy are not null
  // Make a copy of the 'data' prop
  // Find the correct sortValue function and use it for sorting
  let sortedData = data
  if (sortOrder && sortBy) {
    const {sortValue} = config.find((column) => column.label === sortBy)
    sortedData = [...data].sort((a, b) => {
      const valueA = sortValue(a)
      const valueB = sortValue(b)

      const reverseOrder = sortOrder === 'asc' ? 1 : -1

      if (typeof valueA === 'string') {
        return valueA.localeCompare(valueB) * reverseOrder
      } else {
        return (valueA - valueB) * reverseOrder
      }
    })
  }

  return (
    <div>
      {sortOrder} - {sortBy}
      <Table {...props} data={sortedData} config={updatedConfig} />
    </div>
  )
}

function getIcons(label, sortBy, sortOrder) {
  // show both because the label does not match sortBy
  if (label !== sortBy) {
    return (
      <div>
        <GoChevronUp />
        <GoChevronDown />
      </div>
    )
  }
  // now we are assuming the label and sort by match, now we check orders
  if (sortOrder === null) {
    return (
      <div>
        <GoChevronUp />
        <GoChevronDown />
      </div>
    )
  } else if (sortOrder === 'asc') {
    return (
      <div>
        <GoChevronUp />
      </div>
    )
  } else if (sortOrder === 'desc') {
    return (
      <div>
        <GoChevronDown />
      </div>
    )
  }
}
