import SortableTable from './components/SortableTable'

// Just some starter data to populate our table
const data = [
  {name: 'Pumpkin', color: 'bg-orange-500', count: 5, price: 12.0},
  {name: 'Cucumber', color: 'bg-green-500', count: 10, price: 1.0},
  {name: 'Tomato', color: 'bg-red-500', count: 9, price: 0.5},
  {name: 'Eggplant', color: 'bg-purple-500', count: 7, price: 3.0},
  {name: 'Pepper', color: 'bg-yellow-500', count: 8, price: 1.25},
  {name: 'Blueberries', color: 'bg-blue-500', count: 50, price: 0.1},
]

const config = [
  // NEW SORT VALUE
  {label: 'Name', render: (veg) => veg.name, sortValue: (veg) => veg.name},
  {
    label: 'Color',
    render: (veg) => <div className={`p-3 m-2 ${veg.color}`}></div>,
  },
  {
    label: 'Count',
    render: (veg) => veg.count,
    sortValue: (veg) => veg.count,
  },
  {
    label: 'Price',
    render: (veg) => veg.price,
  },
]

// we need a dynamic key fn so we dont hardcode it into our reusable table
const keyFn = (item) => {
  return item.name
}

export default function App() {
  return (
    <div className="container p-5">
      <SortableTable data={data} config={config} keyFn={keyFn} />
    </div>
  )
}
